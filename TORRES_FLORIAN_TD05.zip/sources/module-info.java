/**
 * @author torresf
 *
 */
module fr.umlv.fight {
}