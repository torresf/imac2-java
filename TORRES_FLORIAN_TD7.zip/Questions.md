# Réponses

## Exercice 1
1.
Le constructeur qui prend 4 arguments est déclaré private car il est destiné à être appelé seulement par les autres constructeurs et ne doit pas être appelé à l'extérieur de la classe.
