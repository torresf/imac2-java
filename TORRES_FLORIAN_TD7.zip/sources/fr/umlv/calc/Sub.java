package fr.umlv.calc;

public class Sub implements Expr {

	public Sub(Expr left, Expr right) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int eval() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void displayTree() {
		// TODO Auto-generated method stub
		
	}

}
